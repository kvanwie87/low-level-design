package patterns.casestudy.library.repo;

import java.util.List;

import patterns.casestudy.library.model.Book;

public class BookRepository {
	public List<Book> findByAuthor(String author) {
		return null;
	}
	public List<Book> findByTitle(String title) {
		return null;
	}
}
