package patterns.casestudy.library.api.book;

import java.util.List;

import patterns.casestudy.library.model.Book;

public class BookResponse {
	public List<Book> books;
	public int status;
}
