package patterns.casestudy.library.model;

public class Member {
	public String id;
}
