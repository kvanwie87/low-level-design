package patterns.casestudy.library.model;

public class Book {
	public String bookId;
	public String copyId;
	public String title;
	public String author;
}
