package patterns.casestudy.library.model;

public class Issurance {
	public String id;
	public String copyId;
	public String memberId;
	//Dates
}
