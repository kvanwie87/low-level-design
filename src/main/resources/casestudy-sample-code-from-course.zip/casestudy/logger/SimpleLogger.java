package patterns.casestudy.logger;

import java.util.Map;

public class SimpleLogger {
	//org.apache.logging.log4j.Logger logger = getLogger(this.getClass());
	//Map<LogLevel, Displayer> displayers;
	//ErrorLogger, TraceLogger, Etc
}
