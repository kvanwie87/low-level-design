package patterns.casestudy.logger;

public class Runner {
//	Support multiple severity levels (error, warn, debug, info, etc)
//	Certain logs can  be sent to different or multiple destinations
	public static void main(String[] args) {

	}
}
