package patterns.casestudy.logger;

public interface Displayer {
	public void display(String message);
}
