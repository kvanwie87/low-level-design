package patterns.casestudy.logger;

public interface Logger {
	public void log(LogLevel level, String message);
}
