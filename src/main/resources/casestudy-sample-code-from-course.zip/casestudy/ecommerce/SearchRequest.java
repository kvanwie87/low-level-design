package patterns.casestudy.ecommerce;

public class SearchRequest {
	public String searchStr;
	public FilterInfo filterInfo;
}
