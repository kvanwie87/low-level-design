package patterns.casestudy.ecommerce;

public class ShippingInfo {
	//public Address address;
	//public String type;
	public double cost;
	
}
