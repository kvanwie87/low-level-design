package patterns.casestudy.ecommerce;

public class AddToCartRequest {
	public User user;
	public String cartId;
	public String productId;
	public int quantity;
	
}
