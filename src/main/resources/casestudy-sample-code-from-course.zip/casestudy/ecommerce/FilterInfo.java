package patterns.casestudy.ecommerce;

import java.util.Optional;

public class FilterInfo {
	public Optional<Double> priceMax;
	public Optional<Double> priceMin;
	public Optional<Integer> ratingMax;
	public Optional<Integer> ratingMin;
	//
}
