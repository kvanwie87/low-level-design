package patterns.casestudy.ecommerce;

public class Product {
	public String id;
	public String name;
	public String description;
	public double price;
	public double rating;
}
