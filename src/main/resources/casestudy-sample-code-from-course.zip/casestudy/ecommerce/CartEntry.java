package patterns.casestudy.ecommerce;

public class CartEntry {
	public String entryId;
	public Product product;
	public int quantity;
	public CartEntry(Product product2, int quantity2) {
		// TODO Auto-generated constructor stub
	}
}
