package patterns.casestudy.ecommerce;

public class CheckoutCartRequest {
	public String cartId;
	public PaymentDetails payment;
	public ShippingInfo shipping;
	// public User user;
	//Cart details, payment details billing address, Shipping info, user info 
}
