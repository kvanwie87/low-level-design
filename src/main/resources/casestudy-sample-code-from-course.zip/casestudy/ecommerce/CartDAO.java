package patterns.casestudy.ecommerce;

public class CartDAO {
	public Cart getCartById(String id) {return null;}
}
