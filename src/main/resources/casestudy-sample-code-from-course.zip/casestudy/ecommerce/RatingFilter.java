package patterns.casestudy.ecommerce;

import java.util.List;

public class RatingFilter implements Filter{

	@Override
	public List<Product> filter(List<Product> products, FilterInfo filterInfo) {
		// TODO Auto-generated method stub
		return null;
	}

}
