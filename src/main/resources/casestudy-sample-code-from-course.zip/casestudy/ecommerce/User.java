package patterns.casestudy.ecommerce;

public class User {

}
