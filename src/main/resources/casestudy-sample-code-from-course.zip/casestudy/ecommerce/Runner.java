package patterns.casestudy.ecommerce;

public class Runner {

}
