package patterns.casestudy.inmemorysql.model;

public class Column {
	private String name;
}
