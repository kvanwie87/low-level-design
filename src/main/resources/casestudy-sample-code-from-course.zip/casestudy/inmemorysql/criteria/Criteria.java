package patterns.casestudy.inmemorysql.criteria;

import patterns.casestudy.inmemorysql.model.Row;

public interface Criteria {
	public boolean evaluate(Row row);
}
