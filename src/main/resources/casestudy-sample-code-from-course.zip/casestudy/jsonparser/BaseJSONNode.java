package patterns.casestudy.jsonparser;

public abstract class BaseJSONNode implements JSONNode {

}
