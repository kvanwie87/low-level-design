package patterns.casestudy.jsonparser;

public interface JSONParser {

}
