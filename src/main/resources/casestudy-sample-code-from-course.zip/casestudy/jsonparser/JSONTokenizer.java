package patterns.casestudy.jsonparser;

import java.util.ArrayList;
import java.util.List;

public class JSONTokenizer {
	public List<JSONToken> tokenize(String str) {
//		while(not end of str) {
//			find next field name
//			find next field value
//			identify field value type
//			create token and add to list i.e. JSONToken.createObjectToken(field, value);
//			list.add(token)
//		}
//		return list
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		return new ArrayList<JSONToken>();
	}
}
