package patterns.casestudy.jsonparser;

public interface JSONDeserializer {
	public JSONNode deserialize(JSONToken token);
}
