package patterns.casestudy.stockbroadcast;

public interface Event {

}
