package patterns.casestudy.stockbroadcast;

public interface Subscriber {
	public void update(Event event);
}
